Place folders containing downloaded models in this directory.

You can download my own pre-trained model (2.3 GB) here: https://drive.google.com/uc?id=1rRRY-y1KdVk4UB5qhu7BjQHtfadIOmMk&export=download